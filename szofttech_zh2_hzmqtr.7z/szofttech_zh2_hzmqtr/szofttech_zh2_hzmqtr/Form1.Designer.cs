﻿namespace szofttech_zh2_hzmqtr
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            dataGridView1 = new DataGridView();
            jaratIDDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            legitarsasagDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            indulasiHelyDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            celHelyDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            utasokSzamaDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            idotartamOraDataGridViewTextBoxColumn = new DataGridViewTextBoxColumn();
            bindingSource1 = new BindingSource(components);
            buttonOpen = new Button();
            buttonSave = new Button();
            buttonDelete = new Button();
            buttonAddNew = new Button();
            buttonFunFact = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.AutoGenerateColumns = false;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { jaratIDDataGridViewTextBoxColumn, legitarsasagDataGridViewTextBoxColumn, indulasiHelyDataGridViewTextBoxColumn, celHelyDataGridViewTextBoxColumn, utasokSzamaDataGridViewTextBoxColumn, idotartamOraDataGridViewTextBoxColumn });
            dataGridView1.DataSource = bindingSource1;
            dataGridView1.Location = new Point(28, 74);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(750, 303);
            dataGridView1.TabIndex = 0;
            // 
            // jaratIDDataGridViewTextBoxColumn
            // 
            jaratIDDataGridViewTextBoxColumn.DataPropertyName = "JaratID";
            jaratIDDataGridViewTextBoxColumn.HeaderText = "JaratID";
            jaratIDDataGridViewTextBoxColumn.Name = "jaratIDDataGridViewTextBoxColumn";
            // 
            // legitarsasagDataGridViewTextBoxColumn
            // 
            legitarsasagDataGridViewTextBoxColumn.DataPropertyName = "Legitarsasag";
            legitarsasagDataGridViewTextBoxColumn.HeaderText = "Legitarsasag";
            legitarsasagDataGridViewTextBoxColumn.Name = "legitarsasagDataGridViewTextBoxColumn";
            // 
            // indulasiHelyDataGridViewTextBoxColumn
            // 
            indulasiHelyDataGridViewTextBoxColumn.DataPropertyName = "IndulasiHely";
            indulasiHelyDataGridViewTextBoxColumn.HeaderText = "IndulasiHely";
            indulasiHelyDataGridViewTextBoxColumn.Name = "indulasiHelyDataGridViewTextBoxColumn";
            // 
            // celHelyDataGridViewTextBoxColumn
            // 
            celHelyDataGridViewTextBoxColumn.DataPropertyName = "CelHely";
            celHelyDataGridViewTextBoxColumn.HeaderText = "CelHely";
            celHelyDataGridViewTextBoxColumn.Name = "celHelyDataGridViewTextBoxColumn";
            // 
            // utasokSzamaDataGridViewTextBoxColumn
            // 
            utasokSzamaDataGridViewTextBoxColumn.DataPropertyName = "UtasokSzama";
            utasokSzamaDataGridViewTextBoxColumn.HeaderText = "UtasokSzama";
            utasokSzamaDataGridViewTextBoxColumn.Name = "utasokSzamaDataGridViewTextBoxColumn";
            // 
            // idotartamOraDataGridViewTextBoxColumn
            // 
            idotartamOraDataGridViewTextBoxColumn.DataPropertyName = "IdotartamOra";
            idotartamOraDataGridViewTextBoxColumn.HeaderText = "IdotartamOra";
            idotartamOraDataGridViewTextBoxColumn.Name = "idotartamOraDataGridViewTextBoxColumn";
            // 
            // bindingSource1
            // 
            bindingSource1.DataSource = typeof(zh2_hzmqtr.RepuloJarat);
            // 
            // buttonOpen
            // 
            buttonOpen.Location = new Point(703, 32);
            buttonOpen.Name = "buttonOpen";
            buttonOpen.Size = new Size(75, 23);
            buttonOpen.TabIndex = 1;
            buttonOpen.Text = "Betöltés";
            buttonOpen.UseVisualStyleBackColor = true;
            buttonOpen.Click += buttonOpen_Click;
            // 
            // buttonSave
            // 
            buttonSave.Location = new Point(622, 32);
            buttonSave.Name = "buttonSave";
            buttonSave.Size = new Size(75, 23);
            buttonSave.TabIndex = 2;
            buttonSave.Text = "Mentés";
            buttonSave.UseVisualStyleBackColor = true;
            buttonSave.Click += buttonSave_Click;
            // 
            // buttonDelete
            // 
            buttonDelete.Location = new Point(622, 383);
            buttonDelete.Name = "buttonDelete";
            buttonDelete.Size = new Size(75, 23);
            buttonDelete.TabIndex = 3;
            buttonDelete.Text = "Törlés";
            buttonDelete.UseVisualStyleBackColor = true;
            buttonDelete.Click += buttonDelete_Click;
            // 
            // buttonAddNew
            // 
            buttonAddNew.Location = new Point(703, 383);
            buttonAddNew.Name = "buttonAddNew";
            buttonAddNew.Size = new Size(75, 23);
            buttonAddNew.TabIndex = 4;
            buttonAddNew.Text = "Új sor";
            buttonAddNew.UseVisualStyleBackColor = true;
            buttonAddNew.Click += buttonAddNew_Click;
            // 
            // buttonFunFact
            // 
            buttonFunFact.Location = new Point(55, 25);
            buttonFunFact.Name = "buttonFunFact";
            buttonFunFact.Size = new Size(110, 23);
            buttonFunFact.TabIndex = 5;
            buttonFunFact.Text = "Érdekességek";
            buttonFunFact.UseVisualStyleBackColor = true;
            buttonFunFact.Click += buttonFunFact_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(buttonFunFact);
            Controls.Add(buttonAddNew);
            Controls.Add(buttonDelete);
            Controls.Add(buttonSave);
            Controls.Add(buttonOpen);
            Controls.Add(dataGridView1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)bindingSource1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private DataGridView dataGridView1;
        private Button buttonOpen;
        private BindingSource bindingSource1;
        private Button buttonSave;
        private DataGridViewTextBoxColumn jaratIDDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn legitarsasagDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn indulasiHelyDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn celHelyDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn utasokSzamaDataGridViewTextBoxColumn;
        private DataGridViewTextBoxColumn idotartamOraDataGridViewTextBoxColumn;
        private Button buttonDelete;
        private Button buttonAddNew;
        private Button buttonFunFact;
    }
}