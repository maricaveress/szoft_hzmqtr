﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zh2_hzmqtr
{
    public class RepuloJarat
    {
        //fejléc: JaratID,Legitarsasag,IndulasiHely,CelHely,UtasokSzama,IdotartamOra
        
         
        public int JaratID { get; set; }
        public string Legitarsasag { get; set; } = string.Empty;
        public string IndulasiHely { get; set; } = string.Empty;
        public string CelHely { get; set; } = string.Empty;
        public int UtasokSzama { get; set; }
        public int IdotartamOra { get; set; }
         
    }
}
