﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zh2_hzmqtr
{
    public partial class FormAddNew : Form
    {
        public RepuloJarat UjJarat = new();
        public FormAddNew()
        {
            InitializeComponent();
        }

        private void FormAddNew_Load(object sender, EventArgs e)
        {
            bindingSource1.DataSource = UjJarat;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
