using CsvHelper;
using System.ComponentModel;
using System.Globalization;
using zh2_hzmqtr;

namespace szofttech_zh2_hzmqtr
{
    public partial class Form1 : Form
    {
        BindingList<RepuloJarat> jarat = new();


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //dataGridView1.DataSource = jarat;
            bindingSource1.DataSource = jarat;
        }

        private void buttonOpen_Click(object sender, EventArgs e)
        {
            try
            {
                StreamReader sr = new StreamReader("repulojaratok.txt");
                var csv = new CsvReader(sr, CultureInfo.InvariantCulture);
                var t�mb = csv.GetRecords<RepuloJarat>();

                foreach (var item in t�mb)
                {
                    jarat.Add(item);
                }

                sr.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog.FileName);
                    var csv = new CsvWriter(sw, CultureInfo.InvariantCulture);
                    csv.WriteRecords(jarat);

                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (bindingSource1.Current == null)
            {
                MessageBox.Show("El�sz�r jel�lj ki egy sort!", "Hiba");
                return;
            }
            if (MessageBox.Show("Biztos-biztos t�r�lni szeretn�d, amit kijel�lt�l?", "Meger�s�t� k�rd�sem van fel�d", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                bindingSource1.RemoveCurrent();
            }
        }

        private void buttonAddNew_Click(object sender, EventArgs e)
        {
            FormAddNew formAddNew = new FormAddNew();
            if (formAddNew.ShowDialog() == DialogResult.OK)
            {
                jarat.Add(formAddNew.UjJarat);
            }
        }

        private void buttonFunFact_Click(object sender, EventArgs e)
        {
            int maxIdotartam = 0;
            RepuloJarat leghosszabbJarat = null;
            foreach (var item in jarat)
            {
                if (item.IdotartamOra > maxIdotartam)
                {
                    maxIdotartam = item.IdotartamOra;
                    leghosszabbJarat = item;
                }
            }
            int osszUtasok = 0;
            int newyorkiJaratokSzama = 0;
            foreach (var item in jarat)
            {
                if (item.CelHely == "New York")
                {
                    osszUtasok += item.UtasokSzama;
                    newyorkiJaratokSzama++;
                }
            }
           
            double atlagUtasok = 0;
            if (newyorkiJaratokSzama > 0)
            {atlagUtasok = (double)osszUtasok / newyorkiJaratokSzama; }
            MessageBox.Show($"A leghosszabb menetidej� rep�l�j�rat {leghosszabbJarat.IndulasiHely}r�l {leghosszabbJarat.CelHely}re rep�l, {leghosszabbJarat.IdotartamOra} �ra alatt.\n\n�tlagosan {atlagUtasok} utas �rkezik New Yorkba.");

   
        }
    }
}