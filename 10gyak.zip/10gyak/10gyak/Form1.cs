using _10gyak.Models;

namespace _10gyak
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = this.CreateGraphics();

            Pen pen = new Pen(Color.Fuchsia, 1);
            Brush brush = new SolidBrush(Color.White);

            g.FillEllipse(brush, 0, 0, 100, 100);
            g.Clear(Color.Blue);


            //kontext oszt�ly lep�ld�nyos�t�sa
            HajosContext context = new HajosContext();

            //lek�rdezz�k az �sszes csillag adat�t

            /*var stars = from x in context.StarData select x;*/

            //l�trehozok egy anonim t�pust, �s ez ilyen elemekb�l fog �llni
            var stars = from x in context.StarData select new { x.Hip, x.X, x.Y, x.Magnitude }; //.ToList();

            double nagy�t�s = 200;// Math.Min(ClientRectangle.Height, ClientRectangle.Width) /4 ;

            //eltoljuk a k�zep�re
            int ox = ClientRectangle.Width / 2, oy = ClientRectangle.Height / 2;

            //Rajzolgatunk
            foreach (var star in stars) //bej�rjuk a csillag gy�jtem�nyt
            {
                //sz�r�s
                if (Math.Sqrt(Math.Pow(star.X, 2) + Math.Pow(star.Y, 2)) > 1) continue; //tov�bbl�ptetj�k a ciklust, amikor nem kell
                if (star.Magnitude > 6) continue;

                double size = 20 * Math.Pow(10, star.Magnitude / -2.5);


                double x = star.X * nagy�t�s + ox;
                double y = star.Y * nagy�t�s + oy;

                g.FillEllipse(brush, (float)(x - size / 2), (float)(y - size / 2), (float)size, (float)size);
            }


            var lines = context.ConstellationLines.ToList();

            foreach (var line in lines)
            {
                var star1 = (from x in stars where x.Hip == line.Star1 select x).FirstOrDefault(); //kiveszi az els�t, vagy ha 0, akkor default(null)

                var star2 = (from x in stars where x.Hip == line.Star2 select x).FirstOrDefault();

                if(star1 ==null || star2 ==null) continue;

                double x1 = star1.X * nagy�t�s + ox;
                double y1 = star1.Y * nagy�t�s + oy;

                double x2 = star2.X * nagy�t�s + ox;
                double y2 = star2.Y * nagy�t�s + oy;

                g.DrawLine(pen, (float)x1, (float)y1, (float)x2, (float)y2);
            }


        }
    }
}