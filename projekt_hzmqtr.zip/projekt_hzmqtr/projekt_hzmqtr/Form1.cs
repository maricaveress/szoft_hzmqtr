namespace projekt_hzmqtr
{
    public partial class Form1 : Form
    {
        private string kitalalandoSzo;
        private string elrejtettSzo;
        private List<string> szavak;
        private int maradekProbalkozas;
        private HashSet<char> tippeltSzavak;
        private string kepDirectory = Path.Combine(Application.StartupPath, "Kepek");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            betuGombok();
        }

        //A bet�k gombokk�nt ker�ljenek ki a k�perny�re!
        private void betuGombok()
        {
            tippeltSzavak = new HashSet<char>();
            flowLayoutPanel1.Controls.Clear();

            char[] magyarAbc = "A�BCDE�FGHI�JKLMNO���PQRSTU���VWXYZ".ToCharArray();

            foreach (char betu in magyarAbc)
            {
                Button gomb = new Button
                {
                    Text = betu.ToString(),
                    Width = 30,
                    Height = 30,
                    Margin = new Padding(2)
                };
                gomb.Click += betuGomb_Click;
                flowLayoutPanel1.Controls.Add(gomb);
            }
        }

        //A szavak list�j�t f�jlmegnyit� ablakb�l v�laszhat� f�jlb�l lehessen beolvasni, az esetleges hib�k kezel�se mellett.
        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        szavak = File.ReadAllLines(openFileDialog.FileName).ToList();
                        MessageBox.Show("Sikeres f�jlbet�lt�s.");
                        UjJatek();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(($"Hiba a f�jl bet�lt�sekor. \n{ex.Message}"));
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UjJatek();
        }

        //Lehessen �j j�t�kot kezdeni.
        private void UjJatek()
        {
            if (szavak != null && szavak.Count > 0)
            {
                //A beolvasott list�b�l v�letlenszer�en ker�lj�n kiv�laszt�sra egy sz�.
                Random random = new Random();
                kitalalandoSzo = szavak[random.Next(szavak.Count)].ToUpper();
                elrejtettSzo = new string('_', kitalalandoSzo.Length);
                tippeltSzavak.Clear();
                maradekProbalkozas = 8;
                label1.Text = elrejtettSzo;

                foreach (Button gomb in flowLayoutPanel1.Controls)
                {
                    gomb.Enabled = true;
                }
                kepFrissites();
            }
            else
            {
                MessageBox.Show("El�sz�r k�rlek t�lts be egy sz�list�t.");
            }
        }

        private void kepFrissites()
        {
            string imagePath = Path.Combine(kepDirectory, $"{8 - maradekProbalkozas}.png");
            if (File.Exists(imagePath))
            {
                pictureBox1.Image = Image.FromFile(imagePath);
            }
            else
            {
                MessageBox.Show($"A k�p sajnos nem tal�lhat�.\n{imagePath}");
            }
        }

        private bool Tipp(char betu)
        {
            bool benneVan = false;

            for (int i = 0; i < kitalalandoSzo.Length; i++)
            {
                if (kitalalandoSzo[i] == betu)
                {
                    char[] ideiglenes = elrejtettSzo.ToCharArray();
                    ideiglenes[i] = betu;
                    elrejtettSzo = new string(ideiglenes);
                    benneVan = true;
                }
            }
            return benneVan;
        }

        private void betuGomb_Click(object sender, EventArgs e)
        {
            Button gomb = sender as Button;
            char tippeltSzo = gomb.Text[0];
            gomb.Enabled = false;
            if (szavak != null && szavak.Count > 0)
            {
                if (Tipp(tippeltSzo))
                {
                    label1.Text = elrejtettSzo;
                    if (elrejtettSzo.IndexOf('_') == -1)
                    {
                        MessageBox.Show("Gratul�lok, kital�ltad a sz�t!\nNet�n zseni vagy?\n\nOK gombra kattint�ssal �j j�t�kot kezdhetsz.");
                        UjJatek();
                    }
                }
                else
                {
                    maradekProbalkozas--;
                    kepFrissites();
                    if (maradekProbalkozas == 0)
                    {
                        MessageBox.Show($"�me a kital�land� sz�: \n{kitalalandoSzo}\n\nEz most sajnos nem siker�lt. Pr�b�ld �jra!");
                        UjJatek();
                    }
                }
            }
            else
            {
                MessageBox.Show("El�sz�r k�rlek t�lts be egy sz�list�t.");
            }
        }
    }
}