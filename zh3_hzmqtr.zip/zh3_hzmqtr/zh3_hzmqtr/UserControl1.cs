﻿using CsvHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3e_hzmqtr.Models;

namespace zh3e_hzmqtr
{
    public partial class UserControl1 : UserControl
    {
        DVD_RentalContext context = new DVD_RentalContext();
        public UserControl1()
        {
            InitializeComponent();
            var adatok = (from x in context.Dvds
                          select new
                          {
                              //IDE MÉG VISSZATÉRNI

                              Cím = x.Title,
                              Kategória = x.CategoryFk,
                              Ár = x.NetPrice,
                              Nyelv = x.LanguageFk,
                              Darab = x.Stock,
                          }).ToList();
            dataGridView1.DataSource = adatok;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var adatok = (context.Dvds).ToList();
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if(saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog.FileName);
                    var csv = new CsvWriter(sw,CultureInfo.InvariantCulture);
                    csv.WriteRecords(adatok);
                    MessageBox.Show("Adatok sikeresen mentve!");
                    sw.Close();
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }

        }
    }
}
