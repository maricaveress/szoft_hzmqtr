﻿using System;
using System.Collections.Generic;

namespace zh3e_hzmqtr.Models
{
    public partial class Rental
    {
        public int RentalSk { get; set; }
        public int? MemberFk { get; set; }
        public int? Dvdfk { get; set; }
        public DateTime OutDate { get; set; }
        public DateTime? ReturnDate { get; set; }

        public virtual Dvd? DvdfkNavigation { get; set; }
        public virtual Member? MemberFkNavigation { get; set; }
    }
}
