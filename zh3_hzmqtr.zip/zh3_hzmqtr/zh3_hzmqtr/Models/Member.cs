﻿using System;
using System.Collections.Generic;

namespace zh3e_hzmqtr.Models
{
    public partial class Member
    {
        public Member()
        {
            Rentals = new HashSet<Rental>();
        }

        public int MemberSk { get; set; }
        public string? Name { get; set; }
        public string? Address { get; set; }
        public int? FavCategoryFk { get; set; }
        public int? FavLanguageFk { get; set; }

        public virtual Category? FavCategoryFkNavigation { get; set; }
        public virtual Language? FavLanguageFkNavigation { get; set; }
        public virtual ICollection<Rental> Rentals { get; set; }
    }
}
