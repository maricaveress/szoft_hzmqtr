﻿using System;
using System.Collections.Generic;

namespace zh3e_hzmqtr.Models
{
    public partial class Category
    {
        public Category()
        {
            Dvds = new HashSet<Dvd>();
            Members = new HashSet<Member>();
        }

        public int CategorySk { get; set; }
        public string? Name { get; set; }

        public virtual ICollection<Dvd> Dvds { get; set; }
        public virtual ICollection<Member> Members { get; set; }
    }
}
