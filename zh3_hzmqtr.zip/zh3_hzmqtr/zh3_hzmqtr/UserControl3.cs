﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3e_hzmqtr.Models;

namespace zh3e_hzmqtr
{
    public partial class UserControl3 : UserControl
    {
        DVD_RentalContext context = new DVD_RentalContext();

        public UserControl3()
        {
            InitializeComponent();
            var adatok = (from x in context.Categories
                          select x).ToList();
            dataGridView1.DataSource = adatok;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();
            if (form2.ShowDialog() == DialogResult.OK)
            {
                Category adat = new Category();
                adat.Name = form2.textBox1.Text;
                context.Add(adat);
                try
                {
                    context.SaveChanges();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            }
        }
    }
}
