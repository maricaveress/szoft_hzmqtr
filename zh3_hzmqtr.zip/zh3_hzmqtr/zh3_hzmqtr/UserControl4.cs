﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3e_hzmqtr.Models;

namespace zh3e_hzmqtr
{
    public partial class UserControl4 : UserControl
    {
        DVD_RentalContext context = new DVD_RentalContext();

        public UserControl4()
        {
            InitializeComponent();

            //16
            var legalacsonyabb = (from x in context.Dvds
                                  select x.NetPrice).Min();
            var legmagasabb = (from x in context.Dvds
                               select x.NetPrice).Max();
            var kulonbseg = legmagasabb - legalacsonyabb;
            label1.Text = "A legalacsonyabb és a legmagasabb ár közti különbség: " + kulonbseg.ToString();

            //17
            var atlag = (from x in context.Dvds
                         select x.NetPrice).Average();
            var dragabb = (from x in context.Dvds
                           where x.NetPrice > atlag
                           select x.Title).ToList();
            listBox1.DataSource = dragabb;
            listBox1.DisplayMember = "Name";

            label3.Text = "Az átlagnál drágább DVD-k:";


            //18
            var osszesen = (from x in context.Members
                            select x).Count();
            label2.Text = "Összesen " + osszesen.ToString() + " tag szerepel az adatbázisban.";

        }


    }
}
