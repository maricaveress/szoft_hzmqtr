﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using zh3e_hzmqtr.Models;

namespace zh3e_hzmqtr
{
    public partial class UserControl2 : UserControl
    {
        DVD_RentalContext context = new DVD_RentalContext();

        public UserControl2()
        {
            InitializeComponent();
            var adatok = (from x in context.Members
                          select x).ToList();
            listBox1.DataSource = adatok;
            listBox1.DisplayMember = "Name";
        }

        private void Szures()
        {
            var adatok = (from x in context.Members
                          where x.Name.Contains(textBox1.Text)
                          select x).ToList();
            listBox1.DataSource = adatok;
            listBox1.DisplayMember = "Name";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            Szures();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            Member selected = listBox1.SelectedItem as Member;
            var adat = (from x in context.Rentals
                        where selected.MemberSk == x.MemberFk
                        select new
                        {
                            Kivétel = x.OutDate,
                            Visszahozatal = x.ReturnDate
                        });
            
            dataGridView1.DataSource = adat.ToList();
        }
    }
}
